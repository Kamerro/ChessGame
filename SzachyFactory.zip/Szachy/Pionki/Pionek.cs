﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Pionki
{
    public class Pionek
    {
        public int x;
        public int y;
        public bool is_on_white;
        public Image image{ get; set; }
    }
}
